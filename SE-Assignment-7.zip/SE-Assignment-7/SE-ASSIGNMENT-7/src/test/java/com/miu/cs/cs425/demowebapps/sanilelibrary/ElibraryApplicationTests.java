package com.miu.cs.cs425.demowebapps.nischalelibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElibraryApplicationTests {

    @Test
    void contextLoads() {
    }

}
