This repo contains assignments for SE DE. 
